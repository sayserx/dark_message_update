<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>

<h1 class="h1">message dark</h1>
<h3>ข้อความทั้งหมด</h3>
<p>
	<?php include("info.txt"); ?>
</p>

<div class="message">
    <form action="request.php" method="post">
      <input type="text" class="inputx" name="message" placeholder="message...">
      <button type="submit" name="button">ส่ง</button>
  </form>
</div>


<style>
* {
  margin: 0;
  padding: 0;
}
  .h1 {
    background: black;
    color: #FFFFFF;
    padding: 20px;
    font-size: 20px;
  }
  
  .message {
      position:fixed;
      left:0px;
      bottom:0px;
      width:100%;
      background: #000000;
      text-align: center;
      padding: 10px;
  }
  .message input {
    width: 300px;
    background: #EAEAEA;
    border-radius: 5px;
    border: 1px solid #90FF9D;
    padding: 10px;
    margin-left: -20px;
  }
  .message button {
    background: #75FF62;
    border-radius: 5px;
    border: #3AB528;
    padding: 10px;
    width: 70px;
  }
</style>
</body>
</html>
