<?php
header("location: index.php");
$message = $_POST["message"];
$button = $_POST["button"];
if (isset($button)) {
$file = 'info.txt';
$fp = fopen($file, 'a');
$x = "<br>" . $message . "\n";
fwrite($fp, $x);
fclose($fp);
header("location: index.php");
echo '<META HTTP-EQUIV=\"REFRESH" CONTENT="2; URL=index.php">\n';
}

?>